from setuptools import setup

setup(name="prac35_calculos",
      version="1.0",
      description="Paquete de redondeo y potencia",
      author="Alexis Sáez",
      author_email="cucoalexis@hotmail.com",
      url="https://imalexissaez.github.io/",
      packages=["prac35_calculos"])
